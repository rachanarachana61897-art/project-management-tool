requireAuth();

const user = API.currentUser();
document.getElementById('userChip').textContent = user ? user.username : '';

const socket = io({ auth: { token: API.token() } });

const grid = document.getElementById('projectGrid');
const emptyState = document.getElementById('emptyState');

async function loadProjects() {
  try {
    const projects = await API.get('/projects');
    renderProjects(projects);
  } catch (err) {
    if (err.message.includes('token')) return logout();
    alert(err.message);
  }
}

function renderProjects(projects) {
  grid.innerHTML = '';
  emptyState.classList.toggle('hidden', projects.length > 0);

  projects.forEach(p => {
    const card = document.createElement('div');
    card.className = 'project-card';
    card.onclick = () => window.location.href = `/project.html?id=${p.id}`;

    const avatars = [p.owner, ...p.members]
      .filter((m, idx, arr) => m && arr.findIndex(x => x && x.id === m.id) === idx)
      .slice(0, 4)
      .map(m => `<div class="avatar" title="${m.username}">${initials(m.username)}</div>`)
      .join('');

    card.innerHTML = `
      <h3>${escapeHtml(p.name)}</h3>
      <p>${escapeHtml(p.description || 'No description')}</p>
      <div class="project-meta">
        <span>${p.taskCount} task${p.taskCount === 1 ? '' : 's'}</span>
        <div class="avatar-stack">${avatars}</div>
      </div>
    `;
    grid.appendChild(card);
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// --- New project modal ---
const modal = document.getElementById('newProjectModal');
document.getElementById('newProjectBtn').onclick = () => modal.classList.remove('hidden');
document.getElementById('cancelNewProject').onclick = () => modal.classList.add('hidden');

document.getElementById('confirmNewProject').onclick = async () => {
  const name = document.getElementById('projName').value.trim();
  const description = document.getElementById('projDesc').value.trim();
  const errorBox = document.getElementById('modalError');
  errorBox.classList.add('hidden');

  if (!name) {
    errorBox.textContent = 'Project name is required.';
    errorBox.classList.remove('hidden');
    return;
  }

  try {
    await API.post('/projects', { name, description });
    modal.classList.add('hidden');
    document.getElementById('projName').value = '';
    document.getElementById('projDesc').value = '';
    loadProjects();
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.classList.remove('hidden');
  }
};

// --- Notifications ---
const notifBtn = document.getElementById('notifBtn');
const notifDropdown = document.getElementById('notifDropdown');
const notifBadge = document.getElementById('notifBadge');

async function loadNotifications() {
  const notifications = await API.get('/notifications');
  renderNotifications(notifications);
}

function renderNotifications(notifications) {
  const unread = notifications.filter(n => !n.read).length;
  notifBadge.textContent = unread;
  notifBadge.classList.toggle('hidden', unread === 0);

  if (notifications.length === 0) {
    notifDropdown.innerHTML = '<div class="empty">No notifications yet.</div>';
    return;
  }
  notifDropdown.innerHTML = notifications.slice(0, 20).map(n => `
    <div class="notif-item ${n.read ? '' : 'unread'}">
      <div>${escapeHtml(n.message)}</div>
      <div class="time">${timeAgo(n.createdAt)}</div>
    </div>
  `).join('');
}

notifBtn.onclick = async () => {
  notifDropdown.classList.toggle('hidden');
  if (!notifDropdown.classList.contains('hidden')) {
    await loadNotifications();
    await API.put('/notifications/read-all');
  }
};

socket.on('notification:new', () => loadNotifications());

loadProjects();
loadNotifications();
