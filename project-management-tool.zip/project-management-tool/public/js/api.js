// Small fetch wrapper that automatically attaches the JWT and parses JSON.
const API = {
  base: '/api',

  token() {
    return localStorage.getItem('pmt_token');
  },

  setToken(token) {
    localStorage.setItem('pmt_token', token);
  },

  clearToken() {
    localStorage.removeItem('pmt_token');
    localStorage.removeItem('pmt_user');
  },

  currentUser() {
    const raw = localStorage.getItem('pmt_user');
    return raw ? JSON.parse(raw) : null;
  },

  setCurrentUser(user) {
    localStorage.setItem('pmt_user', JSON.stringify(user));
  },

  async request(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    const token = this.token();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(this.base + path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    });

    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }

    if (!res.ok) {
      const message = (data && data.error) || `Request failed (${res.status})`;
      throw new Error(message);
    }
    return data;
  },

  get(path) { return this.request('GET', path); },
  post(path, body) { return this.request('POST', path, body); },
  put(path, body) { return this.request('PUT', path, body); },
  del(path) { return this.request('DELETE', path); }
};

function requireAuth() {
  if (!API.token()) {
    window.location.href = '/index.html';
  }
}

function logout() {
  API.clearToken();
  window.location.href = '/index.html';
}

function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  return Math.floor(diff / 86400) + 'd ago';
}

function initials(name) {
  return (name || '?').slice(0, 2).toUpperCase();
}
