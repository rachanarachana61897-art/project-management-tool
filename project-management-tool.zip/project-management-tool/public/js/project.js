requireAuth();

const user = API.currentUser();
document.getElementById('userChip').textContent = user ? user.username : '';

const params = new URLSearchParams(window.location.search);
const projectId = params.get('id');
if (!projectId) window.location.href = '/dashboard.html';

const socket = io({ auth: { token: API.token() } });

let currentProject = null;
let currentTasks = [];
let activeTaskId = null;

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

// ---------- Load project + tasks ----------
async function loadProject() {
  try {
    currentProject = await API.get(`/projects/${projectId}`);
    document.getElementById('projectName').textContent = currentProject.name;
    document.getElementById('projectDesc').textContent = currentProject.description || '';
    document.getElementById('deleteProjectBtn').style.display =
      currentProject.owner && currentProject.owner.id === user.id ? 'inline-block' : 'none';
    populateAssigneeOptions();
    socket.emit('project:join', projectId);
  } catch (err) {
    alert(err.message);
    window.location.href = '/dashboard.html';
  }
}

function populateAssigneeOptions() {
  const members = [currentProject.owner, ...currentProject.members]
    .filter((m, idx, arr) => m && arr.findIndex(x => x && x.id === m.id) === idx);

  const options = ['<option value="">Unassigned</option>']
    .concat(members.map(m => `<option value="${m.id}">${escapeHtml(m.username)}</option>`))
    .join('');

  document.getElementById('taskAssignee').innerHTML = options;
  document.getElementById('detailAssignee').innerHTML = options;
}

async function loadTasks() {
  currentTasks = await API.get(`/projects/${projectId}/tasks`);
  renderBoard();
}

function renderBoard() {
  ['todo', 'in_progress', 'done'].forEach(status => {
    const list = document.getElementById(`list-${status}`);
    const tasksForStatus = currentTasks.filter(t => t.status === status);
    document.getElementById(`count-${status}`).textContent = tasksForStatus.length;
    list.innerHTML = tasksForStatus.map(taskCardHtml).join('');
  });

  document.querySelectorAll('.task-card').forEach(el => {
    el.addEventListener('click', () => openTaskDetail(el.dataset.id));
  });
}

function taskCardHtml(t) {
  return `
    <div class="task-card" data-id="${t.id}">
      <h4>${escapeHtml(t.title)}</h4>
      <div class="task-meta">
        <span>${t.assignee ? '👤 ' + escapeHtml(t.assignee.username) : 'Unassigned'}</span>
        <span>💬 ${t.commentCount}</span>
      </div>
    </div>
  `;
}

// ---------- New task modal ----------
const newTaskModal = document.getElementById('newTaskModal');
document.getElementById('newTaskBtn').onclick = () => newTaskModal.classList.remove('hidden');
document.getElementById('cancelNewTask').onclick = () => newTaskModal.classList.add('hidden');

document.getElementById('confirmNewTask').onclick = async () => {
  const title = document.getElementById('taskTitle').value.trim();
  const description = document.getElementById('taskDesc').value.trim();
  const assigneeId = document.getElementById('taskAssignee').value || undefined;
  const errorBox = document.getElementById('taskModalError');
  errorBox.classList.add('hidden');

  if (!title) {
    errorBox.textContent = 'Task title is required.';
    errorBox.classList.remove('hidden');
    return;
  }

  try {
    await API.post(`/projects/${projectId}/tasks`, { title, description, assigneeId });
    newTaskModal.classList.add('hidden');
    document.getElementById('taskTitle').value = '';
    document.getElementById('taskDesc').value = '';
    loadTasks();
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.classList.remove('hidden');
  }
};

// ---------- Task detail modal ----------
const detailModal = document.getElementById('taskDetailModal');

async function openTaskDetail(taskId) {
  activeTaskId = taskId;
  const task = currentTasks.find(t => t.id === taskId);
  if (!task) return;

  document.getElementById('detailTitle').textContent = task.title;
  document.getElementById('detailDesc').textContent = task.description || 'No description.';
  document.getElementById('detailStatus').value = task.status;
  document.getElementById('detailAssignee').value = task.assignee ? task.assignee.id : '';

  await loadComments(taskId);
  detailModal.classList.remove('hidden');
}

document.getElementById('closeDetailModal').onclick = () => {
  detailModal.classList.add('hidden');
  activeTaskId = null;
};

document.getElementById('detailStatus').onchange = async (e) => {
  await API.put(`/tasks/${activeTaskId}`, { status: e.target.value });
  loadTasks();
};

document.getElementById('detailAssignee').onchange = async (e) => {
  await API.put(`/tasks/${activeTaskId}`, { assigneeId: e.target.value || null });
  loadTasks();
};

document.getElementById('deleteTaskBtn').onclick = async () => {
  if (!confirm('Delete this task? This cannot be undone.')) return;
  await API.del(`/tasks/${activeTaskId}`);
  detailModal.classList.add('hidden');
  loadTasks();
};

// ---------- Comments ----------
async function loadComments(taskId) {
  const comments = await API.get(`/tasks/${taskId}/comments`);
  renderComments(comments);
}

function renderComments(comments) {
  const list = document.getElementById('commentsList');
  if (comments.length === 0) {
    list.innerHTML = '<p style="color:#6b7280; font-size:13px;">No comments yet. Start the discussion!</p>';
    return;
  }
  list.innerHTML = comments.map(c => `
    <div class="comment-item">
      <span class="comment-user">${escapeHtml(c.user ? c.user.username : 'Unknown')}</span>
      <span class="comment-time">${timeAgo(c.createdAt)}</span>
      <p>${escapeHtml(c.text)}</p>
    </div>
  `).join('');
  list.scrollTop = list.scrollHeight;
}

document.getElementById('sendCommentBtn').onclick = sendComment;
document.getElementById('commentInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendComment();
});

async function sendComment() {
  const input = document.getElementById('commentInput');
  const text = input.value.trim();
  if (!text || !activeTaskId) return;
  await API.post(`/tasks/${activeTaskId}/comments`, { text });
  input.value = '';
  await loadComments(activeTaskId);
  loadTasks();
}

// ---------- Members ----------
const membersModal = document.getElementById('membersModal');

document.getElementById('membersBtn').onclick = () => {
  renderMembers();
  membersModal.classList.remove('hidden');
};
document.getElementById('closeMembersModal').onclick = () => membersModal.classList.add('hidden');

function renderMembers() {
  const isOwner = currentProject.owner && currentProject.owner.id === user.id;
  const all = [
    { ...currentProject.owner, role: 'Owner' },
    ...currentProject.members.map(m => ({ ...m, role: 'Member' }))
  ];
  document.getElementById('membersList').innerHTML = all
    .map(m => `<div class="member-pill">${escapeHtml(m.username)} · ${m.role}</div>`)
    .join('');
  document.getElementById('addMemberSection').style.display = isOwner ? 'block' : 'none';
}

let searchTimeout;
document.getElementById('memberSearch').addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  const q = e.target.value.trim();
  searchTimeout = setTimeout(() => searchUsers(q), 300);
});

async function searchUsers(q) {
  const resultsBox = document.getElementById('memberResults');
  if (!q) { resultsBox.innerHTML = ''; return; }
  const users = await API.get(`/auth/users?search=${encodeURIComponent(q)}`);
  const existingIds = new Set([
    currentProject.owner.id,
    ...currentProject.members.map(m => m.id)
  ]);
  const filtered = users.filter(u => !existingIds.has(u.id));

  resultsBox.innerHTML = filtered.map(u => `
    <div style="display:flex; justify-content:space-between; align-items:center; padding:6px 0;">
      <span>${escapeHtml(u.username)} <small style="color:#6b7280;">${escapeHtml(u.email)}</small></span>
      <button class="btn small" data-userid="${u.id}">Add</button>
    </div>
  `).join('') || '<p style="color:#6b7280; font-size:13px;">No matching users.</p>';

  resultsBox.querySelectorAll('button[data-userid]').forEach(btn => {
    btn.onclick = async () => {
      await API.post(`/projects/${projectId}/members`, { userId: btn.dataset.userid });
      currentProject = await API.get(`/projects/${projectId}`);
      populateAssigneeOptions();
      renderMembers();
      document.getElementById('memberSearch').value = '';
      resultsBox.innerHTML = '';
    };
  });
}

// ---------- Delete project ----------
document.getElementById('deleteProjectBtn').onclick = async () => {
  if (!confirm('Delete this entire project and all its tasks? This cannot be undone.')) return;
  await API.del(`/projects/${projectId}`);
  window.location.href = '/dashboard.html';
};

// ---------- Real-time updates (bonus feature) ----------
socket.on('task:created', () => loadTasks());
socket.on('task:updated', () => loadTasks());
socket.on('task:deleted', () => loadTasks());
socket.on('comment:created', (comment) => {
  if (comment.taskId === activeTaskId) loadComments(activeTaskId);
  loadTasks();
});
socket.on('project:updated', (proj) => {
  currentProject = proj;
  populateAssigneeOptions();
});
socket.on('project:deleted', () => {
  alert('This project was deleted by its owner.');
  window.location.href = '/dashboard.html';
});

// ---------- Notifications (shared widget) ----------
const notifBtn = document.getElementById('notifBtn');
const notifDropdown = document.getElementById('notifDropdown');
const notifBadge = document.getElementById('notifBadge');

async function loadNotifications() {
  const notifications = await API.get('/notifications');
  const unread = notifications.filter(n => !n.read).length;
  notifBadge.textContent = unread;
  notifBadge.classList.toggle('hidden', unread === 0);
  notifDropdown.innerHTML = notifications.length === 0
    ? '<div class="empty">No notifications yet.</div>'
    : notifications.slice(0, 20).map(n => `
        <div class="notif-item ${n.read ? '' : 'unread'}">
          <div>${escapeHtml(n.message)}</div>
          <div class="time">${timeAgo(n.createdAt)}</div>
        </div>
      `).join('');
}

notifBtn.onclick = async () => {
  notifDropdown.classList.toggle('hidden');
  if (!notifDropdown.classList.contains('hidden')) {
    await loadNotifications();
    await API.put('/notifications/read-all');
  }
};
socket.on('notification:new', () => loadNotifications());

// ---------- Init ----------
(async function init() {
  await loadProject();
  await loadTasks();
  await loadNotifications();
})();
