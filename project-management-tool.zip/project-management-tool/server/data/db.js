// Lightweight file-based JSON database.
// Avoids the need for external DB installs (Mongo/Postgres) while still
// giving persistent storage for users, projects, tasks, comments & notifications.
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'db.json');

function defaultData() {
  return {
    users: [],
    projects: [],
    tasks: [],
    comments: [],
    notifications: []
  };
}

function load() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultData(), null, 2));
  }
  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    return defaultData();
  }
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// In-memory cache, synced to disk on every write for simplicity/durability.
let cache = load();

module.exports = {
  getAll(collection) {
    return cache[collection] || [];
  },
  find(collection, predicate) {
    return (cache[collection] || []).find(predicate);
  },
  filter(collection, predicate) {
    return (cache[collection] || []).filter(predicate);
  },
  insert(collection, item) {
    if (!cache[collection]) cache[collection] = [];
    cache[collection].push(item);
    save(cache);
    return item;
  },
  update(collection, predicate, updates) {
    const list = cache[collection] || [];
    const idx = list.findIndex(predicate);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...updates };
    save(cache);
    return list[idx];
  },
  remove(collection, predicate) {
    const list = cache[collection] || [];
    const idx = list.findIndex(predicate);
    if (idx === -1) return false;
    list.splice(idx, 1);
    save(cache);
    return true;
  },
  reload() {
    cache = load();
  }
};
