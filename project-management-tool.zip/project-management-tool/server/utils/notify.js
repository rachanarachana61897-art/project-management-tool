const { v4: uuidv4 } = require('uuid');
const db = require('../data/db');

/**
 * Create a notification for a user and push it in real-time if they're connected.
 * @param {import('socket.io').Server} io
 * @param {string} userId
 * @param {string} message
 * @param {object} meta - extra data (projectId, taskId, etc.)
 */
function notifyUser(io, userId, message, meta = {}) {
  const notification = {
    id: uuidv4(),
    userId,
    message,
    meta,
    read: false,
    createdAt: new Date().toISOString()
  };
  db.insert('notifications', notification);
  if (io) {
    io.to(`user:${userId}`).emit('notification:new', notification);
  }
  return notification;
}

module.exports = { notifyUser };
