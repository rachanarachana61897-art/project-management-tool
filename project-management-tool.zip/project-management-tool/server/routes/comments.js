const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../data/db');
const authMiddleware = require('../middleware/auth');
const { notifyUser } = require('../utils/notify');

module.exports = function (io) {
  const router = express.Router();
  router.use(authMiddleware);

  function isMember(project, userId) {
    return project.ownerId === userId || project.members.includes(userId);
  }

  function toPublicComment(comment) {
    const user = db.find('users', u => u.id === comment.userId);
    return {
      id: comment.id,
      taskId: comment.taskId,
      text: comment.text,
      user: user ? { id: user.id, username: user.username } : null,
      createdAt: comment.createdAt
    };
  }

  // GET /api/tasks/:taskId/comments
  router.get('/tasks/:taskId/comments', (req, res) => {
    const task = db.find('tasks', t => t.id === req.params.taskId);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    const project = db.find('projects', p => p.id === task.projectId);
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });

    const comments = db.filter('comments', c => c.taskId === task.id)
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    res.json(comments.map(toPublicComment));
  });

  // POST /api/tasks/:taskId/comments - add a comment to communicate within a task
  router.post('/tasks/:taskId/comments', (req, res) => {
    const task = db.find('tasks', t => t.id === req.params.taskId);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    const project = db.find('projects', p => p.id === task.projectId);
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });

    const { text } = req.body;
    if (!text || !text.trim()) return res.status(400).json({ error: 'Comment text is required.' });

    const comment = {
      id: uuidv4(),
      taskId: task.id,
      userId: req.user.id,
      text: text.trim(),
      createdAt: new Date().toISOString()
    };
    db.insert('comments', comment);

    // Notify the assignee and task creator (except the commenter themself)
    const notifyIds = new Set([task.assigneeId, task.createdBy].filter(Boolean));
    notifyIds.delete(req.user.id);
    notifyIds.forEach(uid => {
      notifyUser(io, uid, `New comment on task "${task.title}": ${req.user.username} commented.`, {
        projectId: project.id,
        taskId: task.id
      });
    });

    io.to(`project:${project.id}`).emit('comment:created', toPublicComment(comment));
    res.status(201).json(toPublicComment(comment));
  });

  return router;
};
