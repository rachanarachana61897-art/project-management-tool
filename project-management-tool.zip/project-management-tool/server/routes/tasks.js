const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../data/db');
const authMiddleware = require('../middleware/auth');
const { notifyUser } = require('../utils/notify');

const VALID_STATUSES = ['todo', 'in_progress', 'done'];

module.exports = function (io) {
  const router = express.Router();
  router.use(authMiddleware);

  function isMember(project, userId) {
    return project.ownerId === userId || project.members.includes(userId);
  }

  function toPublicTask(task) {
    const assignee = task.assigneeId ? db.find('users', u => u.id === task.assigneeId) : null;
    const creator = db.find('users', u => u.id === task.createdBy);
    const commentCount = db.filter('comments', c => c.taskId === task.id).length;
    return {
      id: task.id,
      projectId: task.projectId,
      title: task.title,
      description: task.description,
      status: task.status,
      assignee: assignee ? { id: assignee.id, username: assignee.username } : null,
      createdBy: creator ? { id: creator.id, username: creator.username } : null,
      commentCount,
      createdAt: task.createdAt,
      updatedAt: task.updatedAt
    };
  }

  // GET /api/projects/:projectId/tasks
  router.get('/projects/:projectId/tasks', (req, res) => {
    const project = db.find('projects', p => p.id === req.params.projectId);
    if (!project) return res.status(404).json({ error: 'Project not found.' });
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });

    const tasks = db.filter('tasks', t => t.projectId === project.id);
    res.json(tasks.map(toPublicTask));
  });

  // POST /api/projects/:projectId/tasks - create + assign a task
  router.post('/projects/:projectId/tasks', (req, res) => {
    const project = db.find('projects', p => p.id === req.params.projectId);
    if (!project) return res.status(404).json({ error: 'Project not found.' });
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });

    const { title, description, assigneeId, status } = req.body;
    if (!title) return res.status(400).json({ error: 'Task title is required.' });

    if (assigneeId && !isMember(project, assigneeId)) {
      return res.status(400).json({ error: 'Assignee must be a project member.' });
    }

    const task = {
      id: uuidv4(),
      projectId: project.id,
      title,
      description: description || '',
      status: VALID_STATUSES.includes(status) ? status : 'todo',
      assigneeId: assigneeId || null,
      createdBy: req.user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    db.insert('tasks', task);

    if (assigneeId && assigneeId !== req.user.id) {
      notifyUser(io, assigneeId, `You were assigned a new task "${title}" in "${project.name}".`, {
        projectId: project.id,
        taskId: task.id
      });
    }
    io.to(`project:${project.id}`).emit('task:created', toPublicTask(task));

    res.status(201).json(toPublicTask(task));
  });

  // PUT /api/tasks/:id - update status, assignee, title, description
  router.put('/tasks/:id', (req, res) => {
    const task = db.find('tasks', t => t.id === req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    const project = db.find('projects', p => p.id === task.projectId);
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });

    const { title, description, status, assigneeId } = req.body;
    const updates = { updatedAt: new Date().toISOString() };

    if (title !== undefined) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (status !== undefined) {
      if (!VALID_STATUSES.includes(status)) {
        return res.status(400).json({ error: `Status must be one of: ${VALID_STATUSES.join(', ')}` });
      }
      updates.status = status;
    }
    if (assigneeId !== undefined) {
      if (assigneeId && !isMember(project, assigneeId)) {
        return res.status(400).json({ error: 'Assignee must be a project member.' });
      }
      updates.assigneeId = assigneeId || null;
      if (assigneeId && assigneeId !== task.assigneeId && assigneeId !== req.user.id) {
        notifyUser(io, assigneeId, `You were assigned to task "${task.title}" in "${project.name}".`, {
          projectId: project.id,
          taskId: task.id
        });
      }
    }

    const updated = db.update('tasks', t => t.id === task.id, updates);
    io.to(`project:${project.id}`).emit('task:updated', toPublicTask(updated));
    res.json(toPublicTask(updated));
  });

  // DELETE /api/tasks/:id
  router.delete('/tasks/:id', (req, res) => {
    const task = db.find('tasks', t => t.id === req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    const project = db.find('projects', p => p.id === task.projectId);
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });

    db.filter('comments', c => c.taskId === task.id).forEach(c => db.remove('comments', x => x.id === c.id));
    db.remove('tasks', t => t.id === task.id);

    io.to(`project:${project.id}`).emit('task:deleted', { id: task.id, projectId: project.id });
    res.json({ success: true });
  });

  return router;
};
