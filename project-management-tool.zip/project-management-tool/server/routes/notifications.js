const express = require('express');
const db = require('../data/db');
const authMiddleware = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware);

// GET /api/notifications
router.get('/', (req, res) => {
  const notifications = db.filter('notifications', n => n.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(notifications);
});

// PUT /api/notifications/:id/read
router.put('/:id/read', (req, res) => {
  const notification = db.find('notifications', n => n.id === req.params.id && n.userId === req.user.id);
  if (!notification) return res.status(404).json({ error: 'Notification not found.' });
  const updated = db.update('notifications', n => n.id === notification.id, { read: true });
  res.json(updated);
});

// PUT /api/notifications/read-all
router.put('/read-all', (req, res) => {
  db.filter('notifications', n => n.userId === req.user.id && !n.read)
    .forEach(n => db.update('notifications', x => x.id === n.id, { read: true }));
  res.json({ success: true });
});

module.exports = router;
