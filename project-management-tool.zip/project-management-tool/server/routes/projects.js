const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../data/db');
const authMiddleware = require('../middleware/auth');
const { notifyUser } = require('../utils/notify');

module.exports = function (io) {
  const router = express.Router();
  router.use(authMiddleware);

  function isMember(project, userId) {
    return project.ownerId === userId || project.members.includes(userId);
  }

  function toPublicProject(project) {
    const members = project.members.map(id => {
      const u = db.find('users', usr => usr.id === id);
      return u ? { id: u.id, username: u.username, email: u.email } : null;
    }).filter(Boolean);
    const owner = db.find('users', u => u.id === project.ownerId);
    const taskCount = db.filter('tasks', t => t.projectId === project.id).length;
    return {
      id: project.id,
      name: project.name,
      description: project.description,
      owner: owner ? { id: owner.id, username: owner.username } : null,
      members,
      taskCount,
      createdAt: project.createdAt
    };
  }

  // GET /api/projects - list projects the user owns or is a member of
  router.get('/', (req, res) => {
    const projects = db.filter('projects', p => isMember(p, req.user.id));
    res.json(projects.map(toPublicProject));
  });

  // POST /api/projects - create a new group project
  router.post('/', (req, res) => {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ error: 'Project name is required.' });

    const project = {
      id: uuidv4(),
      name,
      description: description || '',
      ownerId: req.user.id,
      members: [],
      createdAt: new Date().toISOString()
    };
    db.insert('projects', project);
    res.status(201).json(toPublicProject(project));
  });

  // GET /api/projects/:id
  router.get('/:id', (req, res) => {
    const project = db.find('projects', p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found.' });
    if (!isMember(project, req.user.id)) return res.status(403).json({ error: 'Access denied.' });
    res.json(toPublicProject(project));
  });

  // POST /api/projects/:id/members - add a member by userId
  router.post('/:id/members', (req, res) => {
    const project = db.find('projects', p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found.' });
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Only the project owner can add members.' });
    }
    const { userId } = req.body;
    const user = db.find('users', u => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found.' });
    if (project.members.includes(userId) || project.ownerId === userId) {
      return res.status(409).json({ error: 'User is already a member.' });
    }
    project.members.push(userId);
    const updated = db.update('projects', p => p.id === project.id, { members: project.members });

    notifyUser(io, userId, `You were added to the project "${project.name}".`, { projectId: project.id });
    io.to(`project:${project.id}`).emit('project:updated', toPublicProject(updated));

    res.json(toPublicProject(updated));
  });

  // DELETE /api/projects/:id - owner only
  router.delete('/:id', (req, res) => {
    const project = db.find('projects', p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found.' });
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Only the project owner can delete this project.' });
    }
    // cascade delete tasks & their comments
    const tasks = db.filter('tasks', t => t.projectId === project.id);
    tasks.forEach(t => {
      db.filter('comments', c => c.taskId === t.id).forEach(c => db.remove('comments', x => x.id === c.id));
      db.remove('tasks', x => x.id === t.id);
    });
    db.remove('projects', p => p.id === project.id);
    io.to(`project:${project.id}`).emit('project:deleted', { id: project.id });
    res.json({ success: true });
  });

  return router;
};
