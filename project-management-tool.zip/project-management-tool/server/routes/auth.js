const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../data/db');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, email: user.email },
    process.env.JWT_SECRET || 'dev_secret_key',
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ error: 'username, email and password are required.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }

  const existing = db.find('users', u => u.email === email || u.username === username);
  if (existing) {
    return res.status(409).json({ error: 'A user with that username or email already exists.' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = {
    id: uuidv4(),
    username,
    email,
    passwordHash,
    createdAt: new Date().toISOString()
  };
  db.insert('users', user);

  const token = signToken(user);
  res.status(201).json({
    token,
    user: { id: user.id, username: user.username, email: user.email }
  });
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required.' });
  }

  const user = db.find('users', u => u.email === email);
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const token = signToken(user);
  res.json({
    token,
    user: { id: user.id, username: user.username, email: user.email }
  });
});

// GET /api/auth/me
router.get('/me', authMiddleware, (req, res) => {
  const user = db.find('users', u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ id: user.id, username: user.username, email: user.email });
});

// GET /api/auth/users?search=xyz  (used when adding project members)
router.get('/users', authMiddleware, (req, res) => {
  const search = (req.query.search || '').toLowerCase();
  const users = db.getAll('users')
    .filter(u => !search || u.username.toLowerCase().includes(search) || u.email.toLowerCase().includes(search))
    .map(u => ({ id: u.id, username: u.username, email: u.email }))
    .slice(0, 10);
  res.json(users);
});

module.exports = router;
