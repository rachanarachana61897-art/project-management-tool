require('dotenv').config();
const path = require('path');
const http = require('http');
const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
const notificationRoutes = require('./routes/notifications');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_key';

app.use(cors());
app.use(express.json());

// Serve the frontend
app.use(express.static(path.join(__dirname, '..', 'public')));

// --- REST API routes ---
app.use('/api/auth', authRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/projects', require('./routes/projects')(io));
app.use('/api', require('./routes/tasks')(io));       // /api/projects/:id/tasks , /api/tasks/:id
app.use('/api', require('./routes/comments')(io));    // /api/tasks/:id/comments

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// --- Socket.io: real-time updates & notifications (bonus feature) ---
io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(new Error('Authentication required'));
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    socket.user = decoded;
    next();
  } catch (err) {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  // Every user gets their own private room for direct notifications
  socket.join(`user:${socket.user.id}`);

  // Client asks to join a project room to receive board/task/comment updates
  socket.on('project:join', (projectId) => {
    socket.join(`project:${projectId}`);
  });

  socket.on('project:leave', (projectId) => {
    socket.leave(`project:${projectId}`);
  });

  socket.on('disconnect', () => {
    // no-op, rooms are cleaned up automatically
  });
});

// Fallback to index.html for direct navigation
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

server.listen(PORT, () => {
  console.log(`🚀 Project Management Tool running at http://localhost:${PORT}`);
});
